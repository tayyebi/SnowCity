﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Snow HTML Editor | ویرایشگر تحت وب برفی")]
[assembly: AssemblyDescription("ASP.NET 4 AND AJAX | شهر برفی")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SnowCity | شهر برفی")]
[assembly: AssemblyProduct("Snow Html Editor | ویرایشگر تحت وب برفی")]
[assembly: AssemblyCopyright("Copyright © SnowCity")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("64545e70-99a6-4579-baba-7f54bb262a51")]

[assembly: AssemblyVersion("1.9.6.0")]
[assembly: AssemblyFileVersion("1.9.6.0")]
